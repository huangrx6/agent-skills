#!/usr/bin/env python3
"""规格 + 布局 → `.excalidraw`（plain JSON 场景）。

## 为什么是 `.excalidraw` 而不是 `.excalidraw.md`

Obsidian 的 Excalidraw 插件把 `.excalidraw.md` 里的场景压成 **lz-string**（实测插件
`main.js` 里有 24 处 `LZString`、`compressToBase64` / `compressToUint8Array` / `compressToUTF16`）——
**lz-string 没有 stdlib Python 等价物**，用它意味着要手抄一份 JS 的压缩算法，或者引依赖。

`*.excalidraw` 是普通 JSON，插件原生读写（同目录的 `my-obsidian-library.excalidrawlib`
就是 plain JSON）。所以本 skill 输出 plain JSON，不碰 lz-string。

## ⚠ 一处必须说清楚的限制：Excalidraw 会重新排版文字

`text_metrics` 的尺寸是我们对"文字占多大"的**推算**（按 Helvetica 实测的字符宽度表算，一律向上取整）。
但容器绑定的文字（`containerId`）在 Excalidraw 里是**由它自己按真实字体重新断行**的。

也就是说：**渲染器是第二个尺寸来源，而且不在我们控制之内。**
如果它的断行跟我们算的不一样（多一行），Excalidraw 会把容器撑高 —— 布局随之偏移，
间隙保证也就不再成立。

这不是猜测出来的隐患，是"同一份文字在两套字体度量下必然有偏差"的必然结果。
它只可能通过**看一张真实渲染的图**来发现，我没法靠本脚本自己验证。

所以：**规格与校验全绿不等于渲染出来就是那样。** 详见 `references/validation.md` 第六节。

## 确定性

同一份规格每次生成**字节相同**（seed 由元素 id 的 sha256 推出，不用随机数），
这样图能进 git、diff 有意义。
"""

from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import math
import os
import re
import sys
from typing import Any

SCENE_TYPE = "excalidraw"
SCENE_VERSION = 2
SOURCE = "excalidraw-diagram skill"
ELEMENT_VERSION = 1
STROKE_WIDTH = 2
ROUGHNESS = 1
TEXT_ALIGN = "center"
VERTICAL_ALIGN = "middle"
# 边标签与连线之间至少要留的空隙。太小会被线穿过（实测过：只上移一个字号时，
# 标签高 15px 而上移 12px，线正好从文字中间过）。
LABEL_GAP = 6.0
NODE_WEIGHT = 10.0      # 标签打分时“压到节点”相对于“压到线”的权。
                        # 线从字上穿过还看得清，字压在框上就分不清这行字属于谁了 ——
                        # 所以兜底选“最不脏”的时候，先避开框。
# Excalidraw 文本元素的 baseline（从文本块顶部到首行基线的距离）。
# 容器绑定的文字在加载时由 Excalidraw 重算，这里给一个合理初值即可。
BASELINE_RATIO = 0.875
_ID_SAFE = re.compile(r"[^A-Za-z0-9_-]+")


def _load_sibling(name: str):
    """动态加载同目录脚本（`scripts/` 不是包，同级 import 在静态层面无法解析）。

    必须把模块注册进 sys.modules 之后再 exec，否则被加载模块里的 `@dataclass` 会炸。
    """
    path = os.path.join(os.path.dirname(os.path.abspath(__file__)), f"{name}.py")
    mod_spec = importlib.util.spec_from_file_location(f"_diagram_{name}", path)
    if mod_spec is None or mod_spec.loader is None:
        raise RuntimeError(f"加载不了同目录模块：{path}")
    module = importlib.util.module_from_spec(mod_spec)
    sys.modules[mod_spec.name] = module
    mod_spec.loader.exec_module(module)
    return module


L = _load_sibling("layout")
palette = _load_sibling("palette")
tm = _load_sibling("text_metrics")
shapes = _load_sibling("shapes")
icons = _load_sibling("icons")


def _stable_int(key: str, salt: str = "") -> int:
    """由字符串推出稳定的伪随机整数。不用 random —— 否则每次生成的文件都不一样，
    图就没法进 git、diff 也没意义。"""
    digest = hashlib.sha256(f"{salt}\x00{key}".encode("utf-8")).digest()
    return int.from_bytes(digest[:4], "big")


def _eid(kind: str, raw: str, index: int = 0) -> str:
    safe = _ID_SAFE.sub("-", str(raw)).strip("-") or "x"
    return f"{kind}-{safe}-{index}" if index else f"{kind}-{safe}"


def _base(el_id: str, el_type: str, x: float, y: float, w: float, h: float,
          stroke: str, background: str, *, stroke_style: str = "solid",
          roundness: dict | None = None, stroke_width: float = STROKE_WIDTH,
          # 默认 solid 而不是 hachure：**文字与箭头也走这里**，它们没有填充，
          # 继承一个"斜条纹"只会让产物里多一堆无意义的字段（Excalidraw 自己的
          # 文字元素就是 solid）。真正的填充档位由 shape_elements / region_elements
          # 显式传进来 —— 那两处才是"用户能选的填充"。
          fill_style: str = "solid", roughness: int = ROUGHNESS,
          extra: dict | None = None) -> dict:
    """所有元素共有的字段。字段集照 Excalidraw 的 `_ExcalidrawElementBase` 来。"""
    el = {
        "id": el_id,
        "type": el_type,
        "x": round(x, 2),
        "y": round(y, 2),
        "width": round(w, 2),
        "height": round(h, 2),
        "angle": 0,
        "strokeColor": stroke,
        "backgroundColor": background,
        "fillStyle": fill_style,
        "strokeWidth": stroke_width,
        "strokeStyle": stroke_style,
        "roughness": roughness,
        "opacity": 100,
        "groupIds": [],
        "frameId": None,
        "roundness": roundness,
        "seed": _stable_int(el_id, "seed"),
        "version": ELEMENT_VERSION,
        "versionNonce": _stable_int(el_id, "nonce"),
        "isDeleted": False,
        "boundElements": None,
        "updated": 1,
        "link": None,
        "locked": False,
        "index": None,
    }
    if extra:
        el.update(extra)
    return el


# ── 节点：矩形 + 容器绑定的文字 ─────────────────────────────
def node_elements(node: dict, placed, box, arrows_out: list[str],
                    arrows_in: list[str], icon_src: list | None = None,
                    icon_height: float | None = None,
                    style: dict | None = None,
                    detail_level: str | None = None) -> list[dict]:
    nid = node["id"]
    shape_id = _eid("node", nid)
    title_id = _eid("title", nid)
    detail_id = _eid("detail", nid)
    # 档位由 layout 那份判据决定（盒子尺寸也是按它算的，两处必须同一个判据）
    has_detail = bool(node.get("detail")) and L.shows_node_detail(node, detail_level)
    text = box.text          # 形状包围盒里面的文字信息（见 layout.NodeBox）

    bound = [{"type": "text", "id": title_id}]
    if has_detail:
        bound.append({"type": "text", "id": detail_id})
    bound += [{"type": "arrow", "id": a} for a in arrows_out + arrows_in]

    kind = node.get("kind")
    emphasis = node.get("emphasis", palette.DEFAULT_EMPHASIS)
    # stroke 也要带上 emphasis —— 否则 critical 节点的填充是警示色、
    # 描边却还是基础层级那一档，而线宽又按 emphasis 来，三者对不上。
    stroke = palette.stroke_for(kind, emphasis)
    fill = palette.fill_for(kind, emphasis)
    stroke_width = palette.emphasis_stroke_width(emphasis)
    elements = shape_elements(shape_id, box.shape, placed, stroke, fill,
                              stroke_width=stroke_width, style=style)
    # 文字与箭头都绑到**主体**那个元素上；圆柱的顶盖只是一个装饰性叠加
    elements[0]["boundElements"] = bound

    # 文字在**形状里能放字的那块区域**居中（不是在整个包围盒里居中）——
    # 圆柱要下沉一个盖高，否则标题会压在椭圆盖上。
    inner_y, inner_h = text_band(box.shape, placed)
    title_h = len(text.lines) * text.font_size * tm.LINE_HEIGHT
    detail_h = len(text.detail_lines) * tm.FONT_DETAIL * tm.LINE_HEIGHT
    top = inner_y + (inner_h - (title_h + detail_h)) / 2.0
    content_w = text.break_units * text.font_size

    # 图标（可选）与文字的摆放，要按**真实 Excalidraw 的规矩**来算。
    #
    # 关键事实（实测）：绑定到容器的文字，官方会把它**水平居中于容器**，并且
    # 重算位置 —— 我们写进去的 x 只影响预览。第一版不知道这一点，按“图标在左、
    # 文字在剩余区域居中”算（文本中心 173.6 vs 节点中心 154.7，偏了 19px），
    # 于是真实渲染里就成了“文字居中、图标丢在左边”。用户的原话：
    # “为什么图标这么靠左，你要考虑整体的协调啊”。
    #
    # 推论：文字的位置不在我们手里（它总在容器中心），所以“图标+文字整体居中”
    # **在数学上做不到** —— 强行去居中会让图标和文字叠在一起。
    # 能做且正确的是：让图标**紧贴可见文字的左边**，间隔就是设计值。
    # 代价是整组视觉重心比中心偏左 (图标宽 + 间隔) / 2 ≈ 19px —— 在 300px 宽的
    # 节点上是 6%，基本看不出来；而换成“把文字解绑”能完美居中，但拖动节点时
    # 文字会留在原地，那是功能倒退，不能接受。
    icon_w = 0.0
    height = icon_height if icon_height else icons.ICON_HEIGHT
    if icon_src:
        scale = icons.fit_scale(icon_src, height)
        icon_w = icons.intrinsic_size(icon_src)[0] * scale

    gap = (layout_gap() if icon_w else 0.0)
    # 文字元素本身就是个居中的盒子（宽度 = 断行宽度），可见文字在它里面居中 ——
    # 所以“可见文字的左边界”是下面这个，而不是盒子的左边界。
    visible_w = max([tm.weighted_units(line) for line in text.lines]
                    + [tm.weighted_units(line) for line in text.detail_lines]
                    or [0.0]) * text.font_size
    center = placed.x + placed.width / 2.0
    tx = center - content_w / 2.0          # 与真实渲染一致（官方会把它放这里）

    if icon_src:
        icon_left = center - visible_w / 2.0 - gap - icon_w
        icon_left = max(icon_left, placed.x + tm.PADDING_X)   # 不越出内边距
        # 竖向与**文字块**对齐（不是与整个可放字区域）—— 带 detail 的节点里
        # 文字是两行，图标对着那两行的中心才协调。
        elements += icons.place(icon_src, icon_left,
                                top + (title_h + detail_h) / 2.0 - height / 2.0,
                                key=_eid("icon", nid), target_height=height)

    elements.append(_text_block(title_id, shape_id, text.lines, tx, top,
                                content_w, text.font_size))
    if has_detail:
        elements.append(_text_block(detail_id, shape_id, text.detail_lines, tx,
                                    top + title_h, content_w, tm.FONT_DETAIL))
    return elements


def layout_gap() -> float:
    """图标与文字之间留的空隙。**单一来源**：布局算盒子宽度时用的是同一个数。"""
    return L.ICON_GAP


def text_band(shape_name: str, placed) -> tuple[float, float]:
    """形状里“能放文字的那一条带”的 (顶边, 高)。"""
    if shape_name == "cylinder":
        cap = shapes.cylinder_cap(placed.width)
        return placed.y + cap, placed.height - cap
    return placed.y, placed.height


def shape_elements(element_id: str, shape_name: str, placed,
                   stroke: str, fill: str,
                   stroke_width: float = STROKE_WIDTH,
                   style: dict | None = None) -> list[dict]:
    """按形状建元素。除圆柱外都是一个元素。

    **圆柱刻意让柱体跨满整个包围盒**，而不是“柱体在下半、盖子在右上”：
    柱体就是箭头与文字绑定的主体，它的包围盒必须等于整个盒子，
    否则箭头会连到柱体上、看起来像“连到了下半截”。
    顶盖椭圆只是叠在上面的装饰（元素顺序 = 叠放顺序，它在后面所以在上）。
    """
    entry = shapes.SHAPES[shape_name]
    # 这里必须换名字：`style` 现在是样式轴那份字典，而旧代码把它当"描边风格串"用
    # （`shapes.stroke_style_for` 的返回值）。同名会被后一次赋值悄悄覆盖。
    resolved = palette.resolve_style(style)
    stroke_style = palette.stroke_style_of(resolved, shapes.stroke_style_for(shape_name))
    fill_style, roughness = resolved["fill"], palette.roughness_of(resolved)
    if shape_name == "cylinder":
        cap = shapes.cylinder_cap(placed.width)
        body = _base(element_id, "rectangle", placed.x, placed.y, placed.width,
                     placed.height, stroke, fill, stroke_style=stroke_style,
                     roundness=palette.roundness_of(resolved, entry.get("roundness")),
                     stroke_width=stroke_width, fill_style=fill_style,
                     roughness=roughness)
        # 顶盖必须跟柱体同一套线型 —— 少了 stroke_style，柱体是虚线、盖子却是实线
        lid = _base(f"{element_id}-lid", "ellipse", placed.x, placed.y,
                    placed.width, cap, stroke, fill, stroke_width=stroke_width,
                    stroke_style=stroke_style, fill_style=fill_style,
                    roughness=roughness)
        # 顶盖与柱体成组：在 Excalidraw 里拖动时它们一起动（否则一拖就散开），
        # 同时这也是一个明确标记 —— “groupIds 非空的是装饰，不是节点”，
        # 校验/量图那边靠它区分顶盖与真节点。
        lid["groupIds"] = [element_id]
        return [body, lid]
    roundness = entry.get("roundness")
    if shape_name == "capsule" and resolved["corners"] == "shape":
        # Excalidraw 没有原生胶囊。type 2 是“按比例取半径”，0.5 就是高的一半 → 真正的胶囊。
        # 只在默认档（听形状自己的）时用它 —— 显式写 sharp 就是要一个普通直角矩形。
        roundness = {"type": 2, "value": 0.5}
    return [_base(element_id, entry["excalidraw"], placed.x, placed.y,
                  placed.width, placed.height, stroke, fill,
                  stroke_style=stroke_style,
                  roundness=palette.roundness_of(resolved, roundness),
                  stroke_width=stroke_width, fill_style=fill_style,
                  roughness=roughness)]


# 比节点细（节点 1.5 / 强调 2.5）：区域是背景层。但不低于 1.0 ——
# 0.75 时手绘的那点抖动几乎看不出来，整块区域会显得比周围"更机械"。
REGION_STROKE_WIDTH = 1.0
# 区域标题的字号住在 `layout.REGION_LABEL_SIZE` —— 它**决定了标题带的高度**
# （带高 = 上边距 + 行数 × 字号 × 行高 + 间隙），所以尺寸链在 layout 那一侧。
# 这里只用它，不再另存一份（两份数值必然漂，而漂的那一份会让框和字对不上）。


def edge_kind_label(edge: dict, level: str | None) -> str | None:
    """`detail: diagnostic` 时，给**不是默认 kind** 的边补上它的中文说明。

    为什么这算「诊断用」：一条虚线的边，光看图分不出它是**异步**还是**可选** ——
    那是语义差别，排查问题时恰恰要看这个。（放在 emit 而不是 layout，是因为它要用
    `palette`；layout 里色板叫 `_palette`，那边没必要为这一处多引一个字段。）

    **默认 kind（`sync`）不补。** 实线 + 箭头方向已经说明了“同步调用”，再写一遍
    是零信息量，而密集图上它会变成一大片重复的字 —— 用户的原话是
    “太拥挤了看着”（一片区域里四五个“同步调用”）。实测一张 12 条边的图里，
    默认 kind 占绝大多数，所以这条一下子就去掉了大部分标签。
    `data` 仍然要补：它也是实线，光看线看不出它是“调用”还是“读写”。

    用户自己写了 `label` 就听用户的 —— 自动补的从不让位给人写的东西。
    """
    if level != "diagnostic" or edge.get("label"):
        return None
    kind = edge.get("kind") or palette.DEFAULT_EDGE_KIND
    if kind == palette.DEFAULT_EDGE_KIND:
        return None
    return palette.EDGE_KINDS.get(kind, {}).get("zh")


def _region_label_x(region: dict, width: float,
                     polylines: list | None) -> tuple[float, bool]:
    """区域标题在标题带里**挑一个不被连线穿过**的横坐标。

    实测踩到：标题原来固定在区域顶部**居中**，而进入该区第一条边是从上一个区下来的
    竖段，正好从中间穿过 —— 端到端夹具一次报出两个区域标题被穿（`07-regions`）。
    区域是背景，可它的标题是要读的字，不能让线从字上过。

    候选是标题带里的一串位置（居中 + 两边各扫若干点）。返回 `(横坐标, 是否脏)` ——
    第二个值决定要不要给标题铺底色：标题带里**每一个候选都被线穿过**时
    （实测 420px 的标题在 468px 的区域里，而竖线正在正中），只能靠底色。
    打分只看"这条线会不会从这段文字的圈里过" —— 和边标签用的是同一套判据。
    """
    if not polylines or width <= 0:
        return region["label_x"], False
    # 搜索范围**是整块区域的宽度**，只留 `REGION_LABEL_MARGIN` 不允许贴到框线后面 ——
    # 一开始卡了 12px 内边距，结果 `boot` 那个 276px 宽的标题在 [−14, 230] 里
    # **每一个候选都被穿过**：竖线在区域正中 x=259，而整个候选区间落在 [−17, 259] 内。
    # 贴着右边缘（268）反而是干净的 —— 标题本来就可以靠边，不必留那么宽的边距。
    margin = L.REGION_LABEL_MARGIN
    left = region["x"] + margin
    right = region["x"] + region["width"] - margin - width
    if right < left:
        # 构上到不了：标题按区域宽度断行（`layout.region_label_lines`），
        # 所以 width ≤ 区域宽 - 2×margin。留着当护栅 —— 真要走到这里，说明尺寸链被改坏了。
        return region["label_x"], False
    centre = region["label_x"] - width / 2.0
    best, best_hits = region["label_x"], None
    spans = [0.5, 0.0, 1.0] + [step / 16 for step in range(1, 16, 2)]
    for fraction in spans:
        x = centre if fraction == 0.5 else left + (right - left) * fraction
        x = max(left, min(right, x))
        hits = _line_hits(x, region["label_y"], width,
                          region.get("label_height") or L.REGION_LABEL_SIZE * tm.LINE_HEIGHT,
                          polylines)
        if best_hits is None or hits < best_hits:
            best, best_hits = x + width / 2.0, hits
        if not hits:
            break
    return best, bool(best_hits)


def region_elements(region: dict, style: dict | None = None,
                    polylines: list | None = None) -> list[dict]:
    """一个区域 = 圆角矩形（交叉网格填充）+ 顶部居中的标题。

    ⚠️ **必须先进 `build_scene` 的 elements 数组。** Excalidraw 的绘制顺序就是
    数组顺序，区域是背景 —— 后进数组的话它会盖住里面的节点（参考图里节点是
    清清楚楚压在网格上面的）。

    ⚠️ 贴一个 `groupIds`：本项目"没有 groupId 的才是节点"这条判定靠它区分装饰
    与节点（见 `node_elements` 附近的说明）。区域是装饰，不带它会把自己混进节点。

    颜色走**层级**而不是写死：`tint`（默认）用极轻的一片，`critical` 用来圈
    "这一段是异常路径"。区域是图上**唯一的整片颜色** —— 在节点只能承载
    单点关注的预算下，它就是让图不沉闷的那一层。
    """
    level = region.get("level", "tint")
    if level not in palette.LEVELS:
        raise ValueError(f"区域 {region['id']!r} 的 level 不认识：{level!r}"
                         f"（可用 {sorted(palette.LEVELS)}；未知值判失败，不 fallback）")
    stroke = palette.frame_stroke(level)      # 退到背景层的颜色，不再和连线撞脸
    fill = palette.LEVELS[level]["fill"]
    # 区域的**局部覆盖**：顶层 style 打底，这个区域自己写的轴盖在上面。
    # 用户要过「只让区域用虚线、节点保持实线」—— 全局 style 表达不了这件事。
    resolved = palette.merge_style(palette.resolve_style(style), region.get("style"))
    el_id = _eid("region", region["id"])
    elements = [_base(el_id, "rectangle", region["x"], region["y"],
                      region["width"], region["height"], stroke, fill,
                      stroke_width=REGION_STROKE_WIDTH,
                      roundness=palette.roundness_of(resolved, {"type": 3}),
                      stroke_style=palette.stroke_style_of(resolved, "solid"),
                      fill_style=resolved["fill"],
                      roughness=palette.roughness_of(resolved),
                      extra={"groupIds": [el_id]})]
    label = region.get("label")
    if label:
        # **断行与尺寸直接用 layout 算好的那份**，不在这里重新量一遂 ——
        # 标题带的高度就是按那几个数算出来的，这里再量一次就可能对不上
        # （而“框与字对不上”正是用户报的那个溢出的根。“同一件几何算两遂必然漂移”
        # 这句在 `_sample_points`/`_segment_may_hit_box` 那两处已经写下过一次）。
        lines = list(region.get("label_lines") or (label,))
        size = region.get("label_size", L.REGION_LABEL_SIZE)
        width = region.get("label_width", 0.0)
        height = region.get("label_height", 0.0)
        text = "\n".join(lines)
        label_id = _eid("region-label", region["id"])
        label_x, dirty = _region_label_x(region, width, polylines)
        elements.append({
            **_base(label_id, "text", label_x - width / 2.0,
                   region["label_y"], width, height,
                   palette.LEVELS[level]["stroke"], "transparent",
                   extra={"groupIds": [el_id]}),
            "text": text,
            "fontSize": size,
            "fontFamily": palette.CANVAS["font_family"],
            "textAlign": "center",
            "verticalAlign": "top",
            "containerId": None,
            "originalText": text,
            "lineHeight": tm.LINE_HEIGHT,
            "baseline": round(size * BASELINE_RATIO, 2),
        })
        if dirty:
            # 标题宽过区域的时候，标题带里**根本不存在**干净位置（实测：420px 的标题
            # 在 468px 的区域里，竖线又在正中）。这时给标题铺一个画布色底 ——
            # 线到字跟前断开，字照样读得清。这和边标签的 needs_backdrop 是同一个办法，
            # 复用而不是另发明一套。
            elements[-1]["backgroundColor"] = palette.CANVAS["background"]
            elements[-1]["roundness"] = {"type": 3}
    return elements


def _text_block(el_id: str, container_id: str, lines: tuple[str, ...],
                x: float, y: float, content_width: float, font_size: float) -> dict:
    """一个容器绑定的文字块。

    x/y 只是初值 —— Excalidraw 对 `containerId` 非空的文字会自己重算位置与换行（见模块顶部那条限制）。
    高度只由行数与字号决定。
    """
    text = "\n".join(lines)
    content_h = len(lines) * font_size * tm.LINE_HEIGHT
    el = _base(el_id, "text", x, y, content_width, content_h,
               palette.CANVAS["text"], "transparent", extra={"roundness": None})
    el.update({
        "text": text,
        "fontSize": font_size,
        "fontFamily": palette.CANVAS["font_family"],
        "textAlign": TEXT_ALIGN,
        "verticalAlign": VERTICAL_ALIGN,
        "containerId": container_id,
        "originalText": text,
        "lineHeight": tm.LINE_HEIGHT,
        "baseline": round(font_size * BASELINE_RATIO, 2),
        "strokeWidth": 1,
    })
    return el


# ── 边：箭头 ────────────────────────────────────────────────
def arrow_element(edge: dict, index: int,
                  style: dict | None = None) -> dict:
    pts = edge["points"]
    x0, y0 = pts[0]
    rel = [[round(px - x0, 2), round(py - y0, 2)] for px, py in pts]
    xs = [p[0] for p in rel]
    ys = [p[1] for p in rel]
    kind = edge.get("kind") or palette.DEFAULT_EDGE_KIND
    edge_style = palette.EDGE_KINDS.get(kind, palette.EDGE_KINDS[palette.DEFAULT_EDGE_KIND])

    el_id = _eid("edge", f"{edge['from']}-{edge['to']}", index)
    # 拐角**不圆**。用户的原话是「就是那种 90 度拐弯的线不行吗」，而 Excalidraw 的
    # `roundness` type 2 会把每个拐角都倒成弧 —— 多段折线的短拐角被糊得几乎看不出角度，
    # 实测图里那几处「钩子」有一半是它造成的。手绘感由 `roughness` 提供，不靠倒角。
    # （`roundness: None` 就是界面上的 Sharp；两点直线没有拐角，不受影响。）
    el = _base(el_id, "arrow", x0, y0, max(xs) - min(xs), max(ys) - min(ys),
               edge_style["stroke"], "transparent", stroke_style=edge_style["style"],
               roundness=None, roughness=palette.roughness_of(
                   palette.resolve_style(style)))
    el.update({
        "points": rel,
        "startArrowhead": None,
        "endArrowhead": "arrow",
        "startBinding": {"elementId": _eid("node", edge["from"]), "focus": 0, "gap": 4},
        "endBinding": {"elementId": _eid("node", edge["to"]), "focus": 0, "gap": 4},
    })
    return el


def polyline_midpoint(pts: list) -> list:
    """沿折线走**一半弧长**处的点 —— 也就是视觉上的中点。"""
    return _midpoint_frame(pts)[0]


def _midpoint_frame(pts: list, frac: float = 0.5) -> tuple[list, tuple[float, float], tuple[float, float]]:
    """折线上某个位置 + 该处的两个方向（反向的入边、出边）。

    两个方向都是相对“沿折线前进”而言的：`back` 指回到来处，`fwd` 指向前方。
    落在一条直段中间时两者共线（角平分退化，只能用法线）；
    落在拐点上时两者不同向 —— 那是真正需要区别对待的情况。

    `frac` 是沿**弧长**的比例，默认 0.5（中点）。之所以可调：标签本来就可以
    沿边滑动，死守中点会把“附近明明有位置”变成“只能压线”。
    """
    if not pts:
        return [0.0, 0.0], (-1.0, 0.0), (1.0, 0.0)
    if len(pts) < 2:
        return list(pts[0]), (-1.0, 0.0), (1.0, 0.0)
    segs = [(pts[i], pts[i + 1], math.dist(pts[i], pts[i + 1]))
            for i in range(len(pts) - 1)]
    total = sum(s[2] for s in segs)
    if total <= 0:
        return list(pts[0]), (-1.0, 0.0), (1.0, 0.0)
    half = total * frac
    walked = 0.0

    def _dir(seg):
        return (seg[1][0] - seg[0][0], seg[1][1] - seg[0][1])

    for i, (a, b, seg_len) in enumerate(segs):
        if walked + seg_len >= half:
            t = (half - walked) / seg_len if seg_len else 0.0
            point = [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t]
            this = _dir(segs[i])
            # 中点落在拐点上有**两种**到达方式，两种都必须认出：
            #   ① 落在本段终点（t≈1）→ 入边是本段，出边是下一段
            #   ② 落在本段起点且 i>0（t≈0）→ 入边是**上一段**，出边是本段
            #
            # ② 不是理论情况，实测真实发生过：两段**近似**等长（实测差约 1e-3 像素）时，
            # 中点会被算在第 1 段的 t≈0 处。那时若按“直段中间”处理，
            # back 与 fwd 会互为**精确反向** → 角平分线退化 → 只剩法线候选
            # → 标签必然压在自己的折线臂上（实测那条 b→d 的边压了 30 个采样点）。
            #
            # 判据是“到拐点的距离 < 半个像素”。这个阈值我前后改过三次，前两次都是猜的：
            #   ① `<= 1e-9`（到端点的**绝对距离**）→ 漏；
            #   ② `t <= 1e-6`（无量纲）→ 还是漏，实测偏差比它大一个量级。
            # 错的根源不是数字大小，是**猜** —— 根本不知道两段长度到底差多少。
            # 换成半个像素就不再依赖猜测：渲染分辨率是 1px，小于半像素的位置差在屏幕上
            # 不可分辨，在本项目尺度上也远小于任何布局阈值（最小间隙 12px）。
            # 要改这个数，依据得是分辨率或布局阈值，不能是为了让某张图好看。
            SUB_PIXEL = 0.5
            near_end = (1.0 - t) * seg_len <= SUB_PIXEL
            near_start = t * seg_len <= SUB_PIXEL
            if near_end and i + 1 < len(segs):
                return list(segs[i][1]), (-this[0], -this[1]), _dir(segs[i + 1])
            if near_start and i > 0:
                back = _dir(segs[i - 1])
                return list(segs[i][0]), (-back[0], -back[1]), this
            return point, (-this[0], -this[1]), this
        walked += seg_len
    a, b = segs[-1][0], segs[-1][1]
    return list(pts[-1]), (a[0] - b[0], a[1] - b[1]), (b[0] - a[0], b[1] - a[1])


def _unit(vector: tuple[float, float]) -> tuple[float, float] | None:
    length = math.hypot(*vector)
    return None if length <= 1e-9 else (vector[0] / length, vector[1] / length)


def _segment_enters_rect(a: tuple[float, float], b: tuple[float, float],
                         left: float, top: float, right: float, bottom: float) -> bool:
    """线段是否从矩形里穿过（密集采样，步长 0.5px）。

    用采样而不是精确求交：这条路径要在“搜一个干净位置”里被调用很多次，
    而正确的标准自带 ≥6px 的空白带 —— 0.5px 的采样误差在这个尺度下无关。
    搜索与守卫用例用**同一个步长**，两者不会结论不一。
    """
    steps = math.ceil(max(abs(b[0] - a[0]), abs(b[1] - a[1])) / 0.5) + 1
    for i in range(steps + 1):
        t = i / steps
        x, y = a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t
        if left <= x <= right and top <= y <= bottom:
            return True
    return False


def _line_hits(x: float, y: float, width: float, height: float,
               obstacles: list) -> int:
    """标签矩形压到了多少段线（或多少条边）。0 = 干净。

    数出来的个数有第二个用途：**一个干净的位置都找不到时，退到"最不脏"的那个**。
    以前是“全都不干净就回到第一个候选”，于是密集图上会出现标签压在节点上 ——
    实测过（正交路由之后线更多了，“注册与装配”直接压在 kernel 的框上）。
    几何只有这一份实现，`_hits_lines` 是它的布尔包装。
    """
    right, bottom = x + width, y + height
    hits = 0
    for polyline in obstacles:
        for a, b in zip(polyline, polyline[1:]):
            if _segment_enters_rect(a, b, x, y, right, bottom):
                hits += 1
    return hits


def _hits_lines(x: float, y: float, width: float, height: float,
                obstacles: list) -> bool:
    return _line_hits(x, y, width, height, obstacles) > 0


def _box_hits(x: float, y: float, width: float, height: float, boxes: list) -> int:
    """标签矩形和这些矩形**重叠**了几处。

    这里必须用**面积重叠**，不能用轮廓：标签整个落在框**里面**时，框的轮廓和它
    根本不相交 —— 实测就是这么漏掉的（标签压在框里，打分却算它干净，底色也就
    永远不触发）。线段用轮廓判据是对的（线是线），矩形要用矩形判据。
    """
    right, bottom = x + width, y + height
    hits = 0
    for left, top, box_right, box_bottom in boxes:
        if x < box_right and right > left and y < box_bottom and bottom > top:
            hits += 1
    return hits


def _candidate_directions(back: tuple[float, float],
                          fwd: tuple[float, float]) -> list[tuple[float, float]]:
    """标签可以往哪几个方向退。先试最合理的，再试备选。

    顺序刻意如此：
    1. **角平分线的外侧** —— 拐点处唯一正确的选择（用法线会有一半盖回入边）
    2. 出边的法线（朝上）—— 直线段的常规位置
    3. 出边的法线（朝下）
    4. 反向入边的两条法线 —— 拐点很尖时靠它绕到另一侧
    """
    out: list[tuple[float, float]] = []
    u, v = _unit(back), _unit(fwd)
    if u and v:
        bisector = _unit((-(u[0] + v[0]), -(u[1] + v[1])))
        if bisector:
            out.append(bisector)
    for base in (v, u):
        if not base:
            continue
        for n in ((-base[1], base[0]), (base[1], -base[0])):
            if n[1] <= 0 and n not in out:      # 优先朝上
                out.append(n)
    for base in (v, u):
        if not base:
            continue
        for n in ((-base[1], base[0]), (base[1], -base[0])):
            if n not in out:
                out.append(n)
    return out or [(0.0, -1.0)]


def label_position(pts: list, width: float, height: float,
                   obstacles: list | None = None,
                   keepouts: list | None = None,
                   gap: float = LABEL_GAP) -> tuple[float, float, bool]:
    """找一个**不与任何连线相交**的标签位置 —— 由脚本自己搜，不靠一个魔法偏移量。

    为什么不能只算一个偏移量：

    1. 旧写法 `(mid.x + 6, mid.y - fontSize)` 只上移了一个字号（12px）而标签高 15px，
       线正好从文字中间穿过 —— 用户看到的“还是有遮挡”就是这个。
    2. 改成“沿法线退开”之后，**拐点**上仍然会盖：中点落在 V 形折线的顶点时，
       标签以顶点为中心，它有一半会压回入射那一段。
    3. 而且标签还可能撞上**别的边**，那是单纯算自家法线永远避不开的。

    返回 `(x, y, 需要底色吗)`。

    `keepouts` 是**节点矩形**（`(x, y, w, h)` 四元组，按面积重叠判，不是轮廓）。
    压到节点比压到线严重得多 —— 线从字上过去
    还看得清，字压在框上就分不清这行字属于谁了。所以打分时节点按 `NODE_WEIGHT` 计权，
    「最不脏」的兜底会优先避开框（实测：五层架构那张里「上传 / 建 job」正好压在
    apps/api 框里 —— 就是因为节点和线同权，兜底选了一个压框但没压线的位置）。

    全都不干净时返回 `True`：调用方会给文字铺一个**底色**，让“被穿过看不清”
    在结构上不可能发生，而不是继续挪到一个一样脏的地方。
    """
    obstacles = obstacles or [list(pts)]
    keepouts = keepouts or []
    radius = math.hypot(width, height) / 2
    # 先试中点，不行再沿边滑 —— 标签本来就可以不在中点，
    # 而死守中点会把“附近明明有位置”变成“只能压线”。
    # 顺序是“离中点由近到远”，所以能用中点时一定用中点。
    first: tuple[float, float] | None = None
    best: tuple[float, float] | None = None
    best_score = -1
    # 取样点与退让量都给足：正交路由之后线段变多，密集图上常常整片中招。
    # 多试一些点的代价很小（一次搜索也就几百次矩形相交判断），比压上去划算。
    #
    # **循环顺序是「先沿线滑、再往外推」**（退让量在外层）。
    # 写反的代价实测过：标签会为了躲开一个障碍而**先往外推 100px**，
    # 而不肯沿着自己那条线滑开一段 —— 结果一堆标签飘在离自己那条线很远的地方，
    # 看着又乱又拥挤（实测最大偏离 **191px**），还说不清这行字到底属于哪条边。
    # 换成先滑再推、最大偏离降到 **31px**，同一张密集图上的重叠仍然是 0。
    for extra in (0.0, 6.0, 12.0, 20.0, 30.0, 45.0, 65.0, 90.0, 120.0, 160.0):
        for frac in (0.5, 0.42, 0.58, 0.34, 0.66, 0.26, 0.74, 0.18, 0.82, 0.1, 0.9):
            mid, back, fwd = _midpoint_frame(pts, frac)
            directions = _candidate_directions(back, fwd)
            for dx, dy in directions:
                reach = radius + gap + extra
                x = mid[0] + dx * reach - width / 2
                y = mid[1] + dy * reach - height / 2
                if first is None:
                    first = (x, y)
                score = (_line_hits(x, y, width, height, obstacles)
                         + NODE_WEIGHT * _box_hits(x, y, width, height, keepouts))
                if score == 0:
                    return round(x, 2), round(y, 2), False
                if best is None or score < best_score:
                    best, best_score = (x, y), score    # 兜底：最不脏的那个
    if best is not None:
        return round(best[0], 2), round(best[1], 2), True
    if first is None:                       # 理论上不可达（候选方向非空），但不靠 assert
        mid = _midpoint_frame(pts)[0]
        first = (mid[0] - width / 2, mid[1] - radius - gap - height / 2)
    return round(first[0], 2), round(first[1], 2), True


def edge_label_element(edge: dict, index: int, obstacles: list | None = None,
                       keepouts: list | None = None) -> dict | None:
    """边标签：一个独立的文字元素，位置由 `label_position` 搜出来。

    刻意**不**绑到箭头上 —— 箭头标签在 Excalidraw 里有自己的定位规则，
    绑上去容易在编辑时漂移；独立元素至少位置是可预测的。

    `obstacles` 传**所有**边的折线（不只是自己那条），`keepouts` 传**节点矩形** ——
    前者撞上就不好读，后者撞上就更糟：分不清这行字属于谁。
    """
    label = edge.get("label")
    if not label:
        return None
    width = round(tm.weighted_units(label) * tm.FONT_DETAIL, 2)
    height = round(tm.FONT_DETAIL * tm.LINE_HEIGHT, 2)
    x, y, needs_backdrop = label_position(edge["points"], width, height,
                                          obstacles, keepouts)
    el_id = _eid("elabel", f"{edge['from']}-{edge['to']}", index)
    el = _base(el_id, "text", x, y, width, height,
               palette.CANVAS["text"], "transparent", extra={"roundness": None})
    if needs_backdrop:
        # 一个干净位置都找不到时，给文字铺一个**底色**（Excalidraw 的文字元素本来
        # 就有 backgroundColor，铺在字后面就是一枚小牌子）。这样“标签被线穿过看不清”
        # 在结构上不可能发生 —— 比继续挪、挪到一个一样脏的地方强。
        el["backgroundColor"] = palette.CANVAS["background"]
        el["roundness"] = {"type": 3}
    el.update({
        "text": label,
        "fontSize": tm.FONT_DETAIL,
        "fontFamily": palette.CANVAS["font_family"],
        "textAlign": "center",
        "verticalAlign": "top",
        "containerId": None,
        "originalText": label,
        "lineHeight": tm.LINE_HEIGHT,
        "baseline": round(tm.FONT_DETAIL * BASELINE_RATIO, 2),
        "strokeWidth": 1,
    })
    return el


# ── 场景 ────────────────────────────────────────────────────
LINEAR_TYPES = {"arrow", "line"}


def element_bounds(el: dict) -> tuple[float, float, float, float]:
    """元素的真实包围盒 (left, top, right, bottom)。

    **线性元素不能用 `x + width`** —— 它的 `x`/`y` 是首点，折线点可以向左/向上
    伸出，所以必须从 `points` 算。

    这条是实测出来的：早期用 `x + width` 量图，得到 744px 的**幽灵空白** ——
    一个箭头让整张图的包围盒无端变宽，于是“图看着不对称”之类的结论全是错的。
    本函数就是那一份实现（`dev-tools/preview.py` 从这里 import，不存第二份）。
    """
    if el.get("type") in LINEAR_TYPES and el.get("points"):
        xs = [el["x"] + p[0] for p in el["points"]]
        ys = [el["y"] + p[1] for p in el["points"]]
        return min(xs), min(ys), max(xs), max(ys)
    return el["x"], el["y"], el["x"] + el["width"], el["y"] + el["height"]


def scene_bounds(elements: list[dict]) -> tuple[float, float, float, float]:
    boxes = [element_bounds(e) for e in elements]
    return (min(b[0] for b in boxes), min(b[1] for b in boxes),
            max(b[2] for b in boxes), max(b[3] for b in boxes))


# 标题底边到内容顶边的距离。数值来源：与最小元素间隙（12px）同量级再放大一档，
# 让标题与图之间看得出“这不是图的一部分”。**未经真实数据校准**，属于待验证。
TITLE_GAP = 28
# 打开文件时用的**名义视口**与留白（Excalidraw 不会告诉我们真实视口有多大）。
# 顶部那条留白是给工具栏的 —— 不留的话内容会压在工具下面。
OPEN_VIEW = (1400.0, 800.0)
OPEN_MARGIN = (60.0, 110.0, 50.0)


def title_element(title: str | None) -> dict | None:
    """图标题。以前 `title` 字段被**完全忽略**（6/6 张图的标题都没画出来）。

    与节点文字不同，标题是**不绑定容器**的自由文字（`containerId = None`）——
    它不属于任何形状，所以 Excalidraw 不会自己重算它的位置，x/y 要算准。
    宽度用**实际行宽**而不是断行档位：档位是给容器用的，标题按档位宽算会
    把一个两字标题撑成 240px，白占画布。
    """
    if not title:
        return None
    box = tm.measure(title, "", font_size=tm.FONT_TITLE)
    lines = box.lines
    width = max(tm.weighted_units(line) for line in lines) * tm.FONT_TITLE
    height = len(lines) * tm.FONT_TITLE * tm.LINE_HEIGHT
    text = "\n".join(lines)
    return {
        "id": _eid("diagram-title", title),
        "type": "text",
        "x": 0.0,          # 居中放在 build_scene 里算（那里才知道内容多宽）
        "y": 0.0,
        "width": round(width, 2),
        "height": round(height, 2),
        "angle": 0,
        "strokeColor": palette.CANVAS["text"],
        "backgroundColor": "transparent",
        "fillStyle": "solid",
        "strokeWidth": 1,
        "strokeStyle": "solid",
        "roughness": ROUGHNESS,
        "opacity": 100,
        "groupIds": [],
        "frameId": None,
        "roundness": None,
        "seed": _stable_int("diagram-title", title),
        "version": ELEMENT_VERSION,
        "versionNonce": _stable_int("diagram-title-nonce", title),
        "isDeleted": False,
        "boundElements": None,
        "updated": 1,
        "link": None,
        "locked": False,
        "index": None,
        "text": text,
        "fontSize": tm.FONT_TITLE,
        "fontFamily": palette.CANVAS["font_family"],
        "textAlign": "center",
        "verticalAlign": "top",
        "containerId": None,
        "originalText": text,
        "lineHeight": tm.LINE_HEIGHT,
        "baseline": round(tm.FONT_TITLE * BASELINE_RATIO, 2),
    }


def build_scene(spec: dict, result, boxes: dict,
                icon_lookup=None, icon_height=None) -> dict:
    elements: list[dict] = []
    by_id = {n["id"]: n for n in spec.get("nodes", [])}
    # 四组样式轴解析一次，透传给每个元素（未知值在 resolve_style 里就抛错了）
    style = palette.resolve_style(spec.get("style"))
    # `detail` 以前是空壳（声明了没人读）。现在它就是信息量档位：见 layout 里
    # shows_node_detail / shows_edge_label 的说明。
    detail_level = spec.get("detail", L.DEFAULT_DETAIL)

    # 区域**第一个**进数组：它是背景，后进会盖住节点（见 region_elements）。
    # 区域标题要在标题带里避开连线，所以这里就得把折线算出来 —— 区域虽然画在最前，
    # 但折线本来就是 `result.edges` 里的现成数据（绝对坐标），不必等箭头那一步。
    region_polylines = [list(edge["points"]) for edge in result.edges]
    for region in L.region_boxes(spec, result.placed, boxes):
        elements += region_elements(region, style, region_polylines)
    # 区域标题也是要读的字，而它不是节点、也不是连线 —— 以前没有任何标签避让它。
    # 用户截图里的那处鸿就是：两条边的“同步调用”压在一个区域标题「探针与门禁」上。
    region_title_boxes = [(e["x"], e["y"], e["x"] + e["width"], e["y"] + e["height"])
                          for e in elements if e["id"].startswith("region-label-")]

    arrows_out: dict[str, list[str]] = {nid: [] for nid in by_id}
    arrows_in: dict[str, list[str]] = {nid: [] for nid in by_id}
    arrow_specs: list[tuple[dict, str]] = []
    for i, edge in enumerate(result.edges):
        eid = _eid("edge", f"{edge['from']}-{edge['to']}", i)
        arrows_out.setdefault(edge["from"], []).append(eid)
        arrows_in.setdefault(edge["to"], []).append(eid)
        arrow_specs.append((edge, eid))

    for nid in by_id:
        placed = result.placed.get(nid)
        if placed is None:
            continue
        icon_src = None
        if icon_lookup is not None and by_id[nid].get("icon"):
            icon_src = icon_lookup(by_id[nid]["icon"])
        if icon_src:
            # 图标高度按节点各算各的（`icon_height` 是整数时是"全部用这个"，否则是表）。
            per_node = (icon_height.get(nid) if isinstance(icon_height, dict)
                        else icon_height)
            elements += node_elements(by_id[nid], placed, boxes[nid],
                                      arrows_out.get(nid, []), arrows_in.get(nid, []),
                                      icon_src=icon_src, icon_height=per_node,
                                      style=style, detail_level=detail_level)
        else:
            elements += node_elements(by_id[nid], placed, boxes[nid],
                                      arrows_out.get(nid, []), arrows_in.get(nid, []),
                                      style=style, detail_level=detail_level)

    # `result.edges` 里的 points **已经是绝对坐标**（`layout._points` 用的是 placed 的坐标），
    # 所以这里直接用，**不能再加一遍起点**。
    #
    # 以前写的是 `edge["points"][0] + p`，把一条真线平移成了另一条假线 ——
    # 标签搜索于是一直在躲不存在的障碍：它返回的位置在自己眼里是干净的，
    # 落到图上却压在真线上（实测某条边被压 19 个采样点）。
    # 这就是 P3“标签压线”反复修不掉的根因。
    polylines = [list(edge["points"]) for edge in result.edges]
    # 节点框单独传给标签搜索（`keepouts`），**不混进 `polylines`**：压到框比压到线
    # 严重得多，打分时要分别计权（NODE_WEIGHT）。只算**真节点** —— 虚节点是布局
    # 内部的东西，不画出来，不该把标签赶走。
    box_keepouts = [(placed.x, placed.y, placed.x + placed.width,
                     placed.y + placed.height)
                    for placed in result.real_nodes().values()]
    # **已经放好的标签自己也是避让物。** 以前每个标签只看连线和节点，
    # 互相不知道对方存在 —— 密集图上实测 12 个标签里 **7 对重叠**
    # （用户的原话：“线上的文本和其他线上的文本可能会重叠”）。
    # 重叠的两个标签谁也读不清，严重性跟压在节点框上一样，所以与节点同权。
    # 外扩半个 `LABEL_GAP`：只求“不重叠”会贴在一起，看着一样拥挤。
    label_keepouts = list(box_keepouts) + region_title_boxes
    for i, (edge, _) in enumerate(arrow_specs):
        elements.append(arrow_element(edge, i, style))
        if not L.shows_edge_label(edge, detail_level):
            continue                      # executive：摘要里不堆边标签
        label = edge_label_element(edge, i, polylines, label_keepouts)
        if label is None:
            auto = edge_kind_label(edge, detail_level)
            if auto:
                label = edge_label_element({**edge, "label": auto}, i, polylines,
                                           label_keepouts)
        if label:
            elements.append(label)
            pad = LABEL_GAP / 2.0
            label_keepouts.append((label["x"] - pad, label["y"] - pad,
                                   label["x"] + label["width"] + pad,
                                   label["y"] + label["height"] + pad))

    # 图标题最后加：它要按已排好的内容来居中，而它自己**不参与**布局。
    # 放的位置是“内容顶边往上 TITLE_GAP”，所以不需要把别的元素往下挪 ——
    # 标题落到 y 为负的地方没关系：下面会把视图滚到内容左上角（见 OPEN_MARGIN_*）。
    title = title_element(spec.get("title"))
    if title is not None and elements:
        left, top, right, _bottom = scene_bounds(elements)
        title["x"] = round(left + (right - left) / 2.0 - title["width"] / 2.0, 2)
        title["y"] = round(top - TITLE_GAP - title["height"], 2)
        elements.append(title)

    # ── 打开时停在哪儿：**必须自己写** ──
    #
    # 实测（真实 excalidraw.com，2026-09-12）：appState 里不给 scrollX/scrollY 时，
    # 应用停在画布原点 —— 内容偏到屏幕角落，得先按一次"缩放至适合"才看得见。
    # 以前这里写着"载入时会自动居中视图"，那是个**没验过的假设**，实测不成立。
    #
    # ⚠ 但这三个字段**有没有被采纳，取决于打开方式**（同一次实测）：
    #   - `#url=` 导入（open_excalidraw_com.py 那条路）：**忽略** —— 它只采纳了
    #     `viewBackgroundColor`（画布真的是我们那个底色），视图仍是 100% 停在原点。
    #   - 当成**场景**打开（Obsidian 插件、编辑器里 Ctrl+O）：**尚未实测**。
    # 写它们仍然是对的（真实 Excalidraw 存盘时就是这些字段，我们的文件应该像一份
    # 正常的场景），但**别把"打开就框住内容"当成已验证的事实** —— 上面那条路不是。
    #
    # 视口按名义尺寸估：Excalidraw 不会告诉我们它多大，但"打开就框住内容"这件事
    # 只需要一个合理的默认值。margin 除以 zoom 是因为屏幕位置 = (场景 + scroll) × zoom。
    left, top, right, bottom = scene_bounds(elements)
    span_x = max(1.0, right - left)
    span_y = max(1.0, bottom - top)
    zoom = round(min(1.0, (OPEN_VIEW[0] - 2 * OPEN_MARGIN[0]) / span_x,
                     (OPEN_VIEW[1] - OPEN_MARGIN[1] - OPEN_MARGIN[2]) / span_y), 2)
    scroll_x = -left + OPEN_MARGIN[0] / zoom
    scroll_y = -top + OPEN_MARGIN[1] / zoom

    return {
        "type": SCENE_TYPE,
        "version": SCENE_VERSION,
        "source": SOURCE,
        "elements": elements,
        "appState": {
            "gridSize": None,
            "viewBackgroundColor": palette.CANVAS["background"],
            "scrollX": round(scroll_x, 2),
            "scrollY": round(scroll_y, 2),
            "zoom": zoom,
        },
        "files": {},
    }


class SpecError(ValueError):
    """规格本身不合法 —— 出图之前就该拦住它。

    为什么不让它半路崩：`boxes_from_spec` 要先定形状才能算尺寸，而形状要读 kind；
    kind 写错时它会报一个误导性的错（实测：“未知 shape: None”）。
    所以 emit 先跑一遍 `validate_spec`，把真正的病因说清楚。

    以前 emit **根本不调用 validate_spec** —— 文档写着“先校验规格再出图”，
    但实际靠调用方自觉；调用方忘了就会在半路崩。
    """


def load_icons(spec: dict, library_path: str | None = None,
               icon_height: float | None = None, full: bool = False):
    """把规格里用到的图标从素材库取出来。**一个都不要就完全不碰文件。**

    返回 `(lookup, sizes)`：
      - `lookup(name)` → 那一项的元素数组
      - `sizes` → `{node_id: (宽, 高)}`，给布局算盒子用

    名字不存在时**判失败不 fallback** —— 静默换一个图标，看图的人根本不知道
    原本想要的是什么（与 `kind` / `shape` / `emphasis` 同一条规矩）。
    """
    wanted = {n["icon"] for n in spec.get("nodes", []) if n.get("icon")}
    if not wanted:
        return None, {}, {}

    path, source = icons.library_path(library_path)
    if not path:
        raise icons.LibraryError(
            f"规格里有节点指定了图标，但没找到素材库（{source}）。"
            f"用 --library 指定，或写一行路径到 ~/.config/excalidraw-library-path")
    library = icons.load(path)

    lookup = {}
    for name in sorted(wanted):
        elements = icons.resolve(library, name)      # 找不到会抛错并列出可用名字
        # 默认只留图形：节点自己已经有标签，素材自带的文字是冗余的，
        # 而且缩到节点尺寸后只有几个像素（见 icons.glyph_only）。
        lookup[name] = list(elements) if full else icons.glyph_only(elements)

    # 每个节点算自己的图标高度 —— 用户要的"适配每一个元素"。
    sizes = {}
    heights = {}
    for node in spec.get("nodes", []):
        name = node.get("icon")
        if not name:
            continue
        elements = lookup[name]
        if icon_height:
            want = icon_height
        else:
            text_box = tm.measure(node.get("label", ""),
                                  node.get("detail", "") if L.shows_node_detail(
                                      node, spec.get("detail", L.DEFAULT_DETAIL)) else "")
            want = icons.height_for(text_box.height)
        heights[node["id"]] = want
        width, height = icons.intrinsic_size(elements)
        scale = icons.fit_scale(elements, want)
        sizes[node["id"]] = (width * scale, height * scale)
    return lookup, sizes, heights


def icon_readability_issues(spec: dict, lookup: dict,
                            icon_height: float | None = None) -> list:
    """图标自带的文字缩到目标高度后看不清 —— 是**选型问题**，不是布局问题。

    实测：vault 里那个素材库是厂商**示意图**集合（图形 + 自带标签），缩到节点里
    当图标用，标签会变成 2px 噪点。图长得没错，是素材选错了。
    这件事只有拿到素材库才知道，所以只能在这里报。
    """
    if not lookup:
        return []
    out = []
    for node in spec.get("nodes", []):
        name = node.get("icon")
        if not name:
            continue
        got = icons.readability(lookup[name], icon_height or icons.ICON_HEIGHT)
        if got is None:
            continue
        smallest, _scale = got
        if smallest < icons.MIN_LEGIBLE_PT:
            out.append(_check_layout().Issue(
                "icon", False, node["id"],
                f"图标 {name!r} 自带的文字缩到 {smallest:.1f}px，看不清",
                advice="这个素材是带文字的示意图、不是单图形图标：换一个更简单的，"
                       "或把图标高度调大。"))
    return out + icon_contrast_issues(spec, lookup)


# 图标与它所在节点底色对比度低于这个值，基本就看不见了。**待验证**。
ICON_FILL_CONTRAST_MIN = 1.5


def icon_contrast_issues(spec: dict, lookup: dict) -> list:
    """图标自带的颜色与它所在节点的底色撞车 —— 撞了就看不见。

    ## 为什么需要这条

    素材自带品牌色（黑 / 蓝 / 红），**不随主题变**。在浅色主题下没问题，
    换到深色主题就会出现"黑底图标压在深色填充上"——图长得没错，是它看不见。

    这件事只有把"图标的颜色"和"节点的填充"放在一起算才知道，
    而且纯机械（算对比度），所以做成检查而不是写在文档里让人自己注意。

    ## 为什么不自动改色

    改色会破坏品牌标识的识别性（一个被改成蓝紫色的 AWS logo 更糟）。
    所以只报，并建议换一个**同义但亮一些**的素材。
    """
    out = []
    for node in spec.get("nodes", []):
        name = node.get("icon")
        if not name or name not in lookup:
            continue
        try:
            fill = palette.fill_for(node.get("kind"),
                                    node.get("emphasis", palette.DEFAULT_EMPHASIS))
        except KeyError:
            continue          # kind / emphasis 不合法的问题由 check_palette 报
        colours = icons.visible_colours(lookup[name])
        if not colours:
            continue
        worst = min((palette.contrast(c, fill), c) for c in colours)
        if worst[0] < ICON_FILL_CONTRAST_MIN:
            out.append(_check_layout().Issue(
                "icon", False, node["id"],
                f"图标 {name!r} 自带的颜色与它所在节点的底色几乎一样"
                f"（对比度 {worst[0]:.2f}），在当前主题下看不见",
                advice="换成同义但亮一些的素材；或换回浅色主题。"
                       "不建议自动改色 —— 那会破坏品牌标识的识别性。"))
    return out


def emit(spec: dict, *, params=None, library: str | None = None,
         icon_height: float | None = None, icon_full: bool = False
         ) -> tuple[dict, Any, Any, list]:
    """跑完整条流水线并返回场景。**校验有阻塞项就不出图。**

    顺序刻意是 validate → layout → check → emit：出图是最后一步，
    前一步不过就不该走到这里。跳过校验直接出图，等于把“不重叠/不溢出”的保证丢掉。
    """
    validator = _load_sibling("validate_spec")
    report = validator.validate(spec)
    if getattr(report, "errors", None):
        detail = "\n".join(f"  - {e.line() if hasattr(e, 'line') else e}"
                           for e in report.errors)
        raise SpecError(f"规格不通过，没有出图：\n{detail}")

    # 主题在**一切之前**定：颜色要被尺寸/校验/标签各处读到，切晚了会前后不一致。
    # `visual` 是视觉方向（旧字段 `theme` 已废弃）；`mood` 是**用户的原话**，
    # 用于 §19"用户明确指定风格时优先用户意图"。
    palette.set_context(spec.get("mood"))
    palette.use_direction(spec.get("visual"), diagram_type=spec.get("type"))

    # 图标必须在算盒子**之前**解析出来 —— 它会影响节点尺寸（第一个外部尺寸来源）
    lookup, icon_sizes, icon_heights = load_icons(spec, library, icon_height,
                                                  icon_full)
    boxes = L.boxes_from_spec(spec, icon_sizes)
    result, outcome, attempts = _check_layout().layout_with_retry(spec, boxes, params)
    extra = icon_readability_issues(spec, lookup or {}, icon_height)
    if extra:
        outcome = _check_layout().Outcome(issues=[*outcome.issues, *extra])
    if outcome.blocking:
        return {}, result, outcome, attempts
    icon_lookup = (lambda name: lookup.get(name)) if lookup else None
    return (build_scene(spec, result, boxes, icon_lookup,
                        icon_heights or icon_height),
            result, outcome, attempts)


def _check_layout():
    return _load_sibling("check_layout")


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="规格 → .excalidraw（plain JSON）")
    ap.add_argument("spec", help="*.diagram.json")
    ap.add_argument("-o", "--out", help="输出路径（默认与规格同名，后缀 .excalidraw）")
    ap.add_argument("--stdout", action="store_true", help="打到标准输出，不写文件")
    ap.add_argument("--library", help="*.excalidrawlib（规格里用到 icon 时才需要）")
    ap.add_argument("--icon-height", type=float,
                    help="强制图标高度（默认按每个节点自身高度算，见 references/icons.md）")
    ap.add_argument("--icon-full", action="store_true",
                    help="保留素材自带的文字（默认只取图形：节点自己已经有标签了）")
    args = ap.parse_args(argv)

    try:
        with open(args.spec, encoding="utf-8") as fh:
            spec = json.load(fh)
    except (OSError, json.JSONDecodeError) as exc:
        print(f"读不到规格：{exc}", file=sys.stderr)
        return 2

    try:
        scene, result, outcome, attempts = emit(spec, library=args.library,
                                                icon_height=args.icon_height,
                                                icon_full=args.icon_full)
    except SpecError as exc:
        print(str(exc), file=sys.stderr)
        return 1
    except ValueError as exc:
        print(f"布局失败：{exc}", file=sys.stderr)
        return 1
    except KeyError as exc:
        print(f"规格里有个值不认识：{exc}", file=sys.stderr)
        return 1
    except icons.LibraryError as exc:
        print(f"图标素材库：{exc}", file=sys.stderr)
        return 1

    if not scene:
        print("校验有阻塞项，不出图：", file=sys.stderr)
        print(_check_layout().format_report(spec, attempts, outcome), file=sys.stderr)
        return 1

    payload = json.dumps(scene, ensure_ascii=False, indent=2)
    if args.stdout:
        print(payload)
        return 0

    out = args.out or os.path.splitext(args.spec)[0] + ".excalidraw"
    try:
        with open(out, "w", encoding="utf-8") as fh:
            fh.write(payload + "\n")
    except OSError as exc:
        print(f"写不了 {out}：{exc}", file=sys.stderr)
        return 2
    n_nodes = len(result.real_nodes())
    print(f"✓ {out}  （{n_nodes} 个节点 / {len(result.edges)} 条边 / "
          f"{len(scene['elements'])} 个元素 / 交叉 {result.crossings}）")
    return 0


if __name__ == "__main__":
    sys.exit(main())
